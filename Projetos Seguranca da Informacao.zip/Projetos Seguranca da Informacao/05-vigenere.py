import string
alfabeto = string.ascii_uppercase

palavra = "RAYSONCIFRADECESARSUBSTITUICAOCIFRADEVIGINERESIMETRICABASE64BLOCO"
chave = "RAYSON"

resultado = ''

for i,char in enumerate(palavra):
    print(i,char)
    if char in alfabeto:
        ci = alfabeto.index(char)
        k = chave[i%len(chave)]
        ki = alfabeto.index(k)

        cii = (ci - ki) % len(alfabeto)
        c = alfabeto[cii]
        resultado += c

print(resultado)

"RAYSON TOME CARNEIRO"
