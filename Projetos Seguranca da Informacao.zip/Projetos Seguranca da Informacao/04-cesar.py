import string
alfabeto = string.ascii_uppercase

palavra = "RDCHXSTGT DH IGTH HXHITBPH RGXEIDVGPUXRDH P HTVJXG RXUGP ST RTHPG RDSXUXRPRPD QPHT64 RXUGP ST KXVTCTGT RAPHHXUXFJT RPSP JB STATH ST PRDGSD RDB IXED ST DETGPRPD (HJQHIXIJXRPD DJ IGPCHEDHXRPD) CJBTGD ST RWPKTH (HXBTIGXRP DJ PHHXBTIGXRP) BDSD ST EGDRTHHPBTCID (UAJMD DJ QADRD)"
chave = 15

resultado = ''

for char in palavra:
    print(char)
    if char in alfabeto:
        ci = alfabeto.index(char)
    
        cii = (ci - chave) % len(alfabeto)
        c = alfabeto[cii]
        resultado += c

print(resultado)

"RAYSON TOME CARNEIRO"
